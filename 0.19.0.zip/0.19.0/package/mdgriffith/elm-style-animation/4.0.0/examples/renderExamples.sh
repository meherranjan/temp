mkdir rendered
elm-make SideMenu.elm --output rendered/SideMenu.html --warn
elm-make Showcase.elm --output rendered/Showcase.html --warn
elm-make Logo.elm --output rendered/Logo.html --warn
elm-make Batman.elm --output rendered/Batman.html --warn
elm-make Gears.elm --output rendered/Gears.html --warn